	  <hr>

      <footer>
        <div class="foot_center3"><p>Copyright &copy; 2021 Zetech University</p>
		<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbspProgrammed by: Hermon Mwongera Kirimi :-P</p>
		</div>
      </footer>