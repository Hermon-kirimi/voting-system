	<div class="navbar navbar-fixed-top">
	<div class="navbar-inner">
	<div class="container">
	     
		<a class="brand">
		<img src="images/zetech4.jpg" width="60" height="60">
 	</a>
	<a class="brand">
	 <h2>Zetech University Online Voting System</h2>
	 <div class="chmsc_nav"><font size="4" color="white">Zetech University</font></div>
 	</a>

	<?php include('head.php'); ?>
 
 
	</div>
	</div>
	</div>
	