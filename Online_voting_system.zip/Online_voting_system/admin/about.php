<h1><font color="gray">Online Voting System</font></h1>
</br>
<font color="#555">
<p>Zetech University</p>
<p>Develop By:</p>
</font>
</br>
<div id="accordion2" class="accordion">
<div class="accordion-group">
<div class="accordion-heading">
<a class="accordion-toggle" href="#collapseOne" data-parent="#accordion2" data-toggle="collapse">Hermon Mwongera Kirimi</a>
</div>
<div id="collapseOne" class="accordion-body collapse" style="height: 0px;">
<div class="accordion-inner"> 
<p><font color="gray">Position:&nbsp;Programmer</font></p>
<p><font color="gray">FirstName:&nbsp;Hermon Mwongera</font></p>
<p><font color="gray">LastName:&nbsp;Kirimi</font></p>
<p><font color="gray">Age:&nbsp;22</font></p>
<p><font color="gray">Address:&nbsp;Nairobi city</font></p>
<p><font color="gray">Email:&nbsp;4hermon.m.Kirimi@gmail.com</font></p>
<p><font color="gray">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;kirimimwongera@zetech.com</font></p>
<div class="user_image"><img src="project_member/me.jpg" width="200" height="250"></div>
</div>
</div>
</div>

<!-- <div class="accordion-group">
<div class="accordion-heading">
<a class="accordion-toggle" href="#collapse4" data-parent="#accordion2" data-toggle="collapse">Sherwin Laylon</a>
</div>
<div id="collapse4" class="accordion-body collapse">
<div class="accordion-inner">
<p><font color="gray">Position:&nbsp;Project Manager</font></p>
<p><font color="gray">FirstName:&nbsp;Sherwin</font></p>
<p><font color="gray">LastName:&nbsp;Laylon</font></p>
<p><font color="gray">Age:&nbsp;19</font></p>
<p><font color="gray">Address:&nbsp;St. Therese Village</font></p>
<p><font color="gray">Email:&nbsp;zachary.sherwin@gmail.com</font></p>
<div class="user_image"><img src="project_member/sherwin.png" width="200" height="250"></div>
</div>
</div>
</div>

<div class="accordion-group">
<div class="accordion-heading">
<a class="accordion-toggle" href="#collapseTwo" data-parent="#accordion2" data-toggle="collapse">May Memdoza</a>
</div>
<div id="collapseTwo" class="accordion-body collapse">
<div class="accordion-inner">
<p><font color="gray">Position:&nbsp;Assistant Project Manager</font></p>
<p><font color="gray">FirstName:&nbsp;May</font></p>
<p><font color="gray">LastName:&nbsp;Mendoza</font></p>
<p><font color="gray">Age:&nbsp;20</font></p>
<p><font color="gray">Address:&nbsp;Victorias City</font></p>
<p><font color="gray">Email:&nbsp;</font></p>
<div class="user_image"><img src="project_member/may.jpg" width="200" height="250"></div>
</div>

</div>
</div>
<div class="accordion-group">
<div class="accordion-heading">
<a class="accordion-toggle" href="#collapse3" data-parent="#accordion2" data-toggle="collapse">Golda Nepomuceno</a>
</div>
<div id="collapse3" class="accordion-body collapse">
<div class="accordion-inner">
<p><font color="gray">Position:&nbsp;System Analyst</font></p>
<p><font color="gray">FirstName:&nbsp;Golda</font></p>
<p><font color="gray">LastName:&nbsp;Nepomuceno</font></p>
<p><font color="gray">Age:&nbsp;20</font></p>
<p><font color="gray">Address:&nbsp;Silay City</font></p>
<p><font color="gray">Email:&nbsp;golda@yahoo.com</font></p>
<div class="user_image"><img src="project_member/golda.png" width="200" height="250"></div>
</div>
</div>
</div>


<div class="accordion-group">
<div class="accordion-heading">
<a class="accordion-toggle" href="#collapse5" data-parent="#accordion2" data-toggle="collapse">Mary Ver Liboon</a>
</div>
<div id="collapse5" class="accordion-body collapse">
<div class="accordion-inner">
<p><font color="gray">Position:&nbsp;Designer</font></p>
<p><font color="gray">FirstName:&nbsp;Mary Ver</font></p>
<p><font color="gray">LastName:&nbsp;Liboon</font></p>
<p><font color="gray">Age:&nbsp;18</font></p>
<p><font color="gray">Address:&nbsp;Talisay City</font></p>
<p><font color="gray">Email:&nbsp;michever_whte@yahoo.com</font></p>
<div class="user_image"><img src="project_member/ver.jpg" width="200" height="250"></div>
</div>
</div>
</div> -->
	  </div>
	  </div>